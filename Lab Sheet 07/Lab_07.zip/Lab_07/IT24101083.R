setwd("/Users/jiruththisiva/Desktop/Lab_07")

a <- 0
b <- 40
start_min <- 10
end_min   <- 25
p_uniform <- (end_min - start_min) / (b - a)


lambda <- 1/3
t <- 2  
p_exp_at_most_2 <- 1 - exp(-lambda * t)


mu <- 100
sigma <- 15

z_130 <- (130 - mu) / sigma
p_gt_130 <- 1 - pnorm(z_130)


z95 <- qnorm(0.95)
iq95 <- mu + z95 * sigma


cat(" P(train between 8:10 and 8:25) =", p_uniform, "\n")
cat(" P(update <= 2 hours) =", format(p_exp_at_most_2, digits=6), "\n")
cat(" P(IQ > 130) =", format(p_gt_130, digits=6), "\n")
cat(" 95th percentile IQ =", format(iq95, digits=6), "\n")
