
setwd("/Users/jiruththisiva/Desktop/Lab 05")

delivery_data <- read.table('Exercise - Lab 05.txt', header = TRUE, stringsAsFactors = FALSE)
Delivery_Times <- data.frame(Delivery_Time_minutes = as.numeric(delivery_data$Delivery_Time_minutes))

str(Delivery_Times)
class(Delivery_Times$Delivery_Time_minutes)


head(Delivery_Times)

hist(Delivery_Times$Delivery_Time_minutes, 
     breaks = seq(20, 70, by = (70-20)/9), 
     right = FALSE,  
     main = "Histogram of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Frequency",
     col = "lightblue",
     border = "black")


freq_table <- table(cut(Delivery_Times$Delivery_Time_minutes, 
                        breaks = seq(20, 70, by = (70-20)/9), 
                        right = FALSE))


cum_freq <- cumsum(freq_table)


plot(seq(20, 70, by = (70-20)/9)[-10], cum_freq,  
     type = "b",  
     pch = 16,    
     col = "red",
     main = "Cumulative Frequency Polygon (Ogive) of Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     xlim = c(20, 70))

